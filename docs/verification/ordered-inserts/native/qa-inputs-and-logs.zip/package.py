from pathlib import Path
import json,zipfile,wave,shutil
r=Path('build/ordered-inserts/native');out=Path('docs/verification/ordered-inserts/native');allrows=json.loads((r/'pcm-records.json').read_text());selected={x['label']:x for x in allrows if x['label'].startswith(('lv-','old-')) or '-long-' in x['label']};rows=list(selected.values());refs={}
with wave.open(str(r/'meter-long-steps.wav'),'rb') as w:
 for row in rows:
  if row['label'].startswith('youlean-'):
   reference='reference-'+str(row['firstFrame'])+'.s16';row['reference']=reference;w.setpos(row['firstFrame']);refs[reference]=w.readframes(row['frames'])
with zipfile.ZipFile(out/'native-pcm.zip','w',zipfile.ZIP_DEFLATED) as z:
 for row in rows:z.write(out/(row['label']+'.f32'),row['label']+'.f32')
 for name,data in refs.items():z.writestr(name,data)
 for name in ['lv-render-before-recall.wav','lv-render-fresh-recall.wav']:z.write(out/name,name)
 z.write(r/'meter-long-steps.wav','meter-long-steps.wav')
(out/'pcm-records.json').write_text(json.dumps(rows,indent=2))
with zipfile.ZipFile(out/'qa-inputs-and-logs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pattern in ['*.log','*.py','*long.soundplus','*QA.soundplus']:
  for f in r.glob(pattern):z.write(f,f.name)
# Raw selected bytes are inside the portable archive, avoiding duplicate large files in Git.
for f in out.glob('*.f32'):f.unlink()
for name in ['lv-render-before-recall.wav','lv-render-fresh-recall.wav']:(out/name).unlink()
