from pathlib import Path
import json,hashlib,uuid,wave,math,array
r=Path('build/ordered-inserts/native').resolve();f=r/'meter-long-steps.wav'
with wave.open(str(f),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000)
 for sec in range(90):
  level=0 if sec<2 or sec>=72 else 10**((-8 if sec<12 else -20)/20)
  a=array.array('h')
  for n in range(48000):
   v=round(level*32767*math.sin(2*math.pi*1000*n/48000));a.extend([v,v])
  w.writeframes(a.tobytes())
for case in ['Track','Master','Rear']:
 s=json.loads((r/('Youlean '+case+' QA.soundplus')).read_text());p=s['payload'];p['id']=uuid.uuid4().hex;p['revision']=1;p['name']='Youlean '+case+' long-step QA';p['playhead']=0
 for l in p['original']['layers']:
  l['first']=0;l['last']=90*48000;src=l['source'];src.update(id='external-'+uuid.uuid4().hex,path=str(f),name=f.name,size=f.stat().st_size,samples=90*48000,modified=f.stat().st_mtime_ns,inode=f.stat().st_ino)
 s['sha256']=hashlib.sha256(json.dumps(p,ensure_ascii=False,separators=(', ', ': ')).encode()).hexdigest();(r/('Youlean '+case+' long.soundplus')).write_text(json.dumps(s,ensure_ascii=False))
