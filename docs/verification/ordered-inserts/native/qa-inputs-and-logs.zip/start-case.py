from pathlib import Path
import json,sys,time
r=Path('build/ordered-inserts/native').resolve();f=r/sys.argv[1];s=json.loads(f.read_text());p=s['payload'];a=r/'data/designer-autosave';(a/(p['id']+'.soundplus')).write_text(json.dumps(s,ensure_ascii=False));(a/(p['id']+'.json')).write_text(json.dumps({'version':1,'id':p['id'],'revision':p['revision'],'savedFile':str(f),'state':'saved','updated':int(time.time()*1000)}));(a/'active.json').write_text(json.dumps({'version':1,'id':p['id']}))
