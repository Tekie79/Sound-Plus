from pathlib import Path
import json,array,math,sys,hashlib
r=Path('build/ordered-inserts/native');paths=list((r/'captures').glob('*.f32'));p=max(paths,key=lambda p:p.stat().st_mtime);channels=int(sys.argv[2]) if len(sys.argv)>2 else 2
b=p.read_bytes();n=len(b)//(4*channels);start=int(sys.argv[3]) if len(sys.argv)>3 else max(0,n-48000);w=b[start*4*channels:min(n,start+48000)*4*channels];out=Path('docs/verification/ordered-inserts/native');out.mkdir(exist_ok=True);label=sys.argv[1];dest=out/(label+'.f32');dest.write_bytes(w);a=array.array('f');a.frombytes(w)
x={'label':label,'raw':str(p.resolve()),'firstFrame':start,'frames':len(w)//(4*channels),'channels':channels,'rms':math.sqrt(sum(v*v for v in a)/len(a)),'sha256':hashlib.sha256(w).hexdigest()};records=json.loads((r/'pcm-records.json').read_text()) if (r/'pcm-records.json').exists() else [];records.append(x);(r/'pcm-records.json').write_text(json.dumps(records,indent=2));print(x)
