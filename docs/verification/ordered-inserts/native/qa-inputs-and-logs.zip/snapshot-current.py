from pathlib import Path
import json,sys
r=Path('build/ordered-inserts/native');identity=json.loads((r/'data/designer-autosave/active.json').read_text())['id'];out=Path('docs/verification/ordered-inserts/native')
for e in (r/'data/live-inserts').rglob('endpoint.json'):
 s=json.loads(e.read_text())
 if s['binding']['document']==identity:
  (out/(sys.argv[1]+'-endpoint.json')).write_text(json.dumps(s,indent=2));state=Path(s['exchange']).parent/'state.json';(out/(sys.argv[1]+'-state.json')).write_bytes(state.read_bytes());print(s['binding']['owner'],s['generation'])
